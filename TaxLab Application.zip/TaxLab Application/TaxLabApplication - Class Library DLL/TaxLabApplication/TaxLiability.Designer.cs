﻿namespace TaxLabApplication
{
    partial class TaxLiability
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CalculateButton = new System.Windows.Forms.Button();
            this.SalaryInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.OutputLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TaxRate4 = new System.Windows.Forms.TextBox();
            this.TaxRate3 = new System.Windows.Forms.TextBox();
            this.TaxRate2 = new System.Windows.Forms.TextBox();
            this.TaxRate1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Max4 = new System.Windows.Forms.TextBox();
            this.Max3 = new System.Windows.Forms.TextBox();
            this.Max2 = new System.Windows.Forms.TextBox();
            this.Max1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Min4 = new System.Windows.Forms.TextBox();
            this.Min3 = new System.Windows.Forms.TextBox();
            this.Min2 = new System.Windows.Forms.TextBox();
            this.Min1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // CalculateButton
            // 
            this.CalculateButton.BackColor = System.Drawing.Color.Azure;
            this.CalculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalculateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.CalculateButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CalculateButton.Location = new System.Drawing.Point(217, 83);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(135, 40);
            this.CalculateButton.TabIndex = 0;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = false;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // SalaryInput
            // 
            this.SalaryInput.BackColor = System.Drawing.Color.Azure;
            this.SalaryInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryInput.ForeColor = System.Drawing.Color.Black;
            this.SalaryInput.Location = new System.Drawing.Point(15, 83);
            this.SalaryInput.MaxLength = 9;
            this.SalaryInput.MinimumSize = new System.Drawing.Size(4, 40);
            this.SalaryInput.Name = "SalaryInput";
            this.SalaryInput.Size = new System.Drawing.Size(180, 35);
            this.SalaryInput.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(449, 31);
            this.label1.TabIndex = 3;
            this.label1.Text = "Calulate your Annual Tax Liability";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.OutputLabel);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(12, 149);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 204);
            this.panel1.TabIndex = 4;
            // 
            // OutputLabel
            // 
            this.OutputLabel.AutoSize = true;
            this.OutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutputLabel.ForeColor = System.Drawing.Color.White;
            this.OutputLabel.Location = new System.Drawing.Point(19, 37);
            this.OutputLabel.Name = "OutputLabel";
            this.OutputLabel.Size = new System.Drawing.Size(42, 25);
            this.OutputLabel.TabIndex = 2;
            this.OutputLabel.Text = "n/a";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "$";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Your annual tax liability is";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.TaxRate4);
            this.panel2.Controls.Add(this.TaxRate3);
            this.panel2.Controls.Add(this.TaxRate2);
            this.panel2.Controls.Add(this.TaxRate1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.Max4);
            this.panel2.Controls.Add(this.Max3);
            this.panel2.Controls.Add(this.Max2);
            this.panel2.Controls.Add(this.Max1);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.Min4);
            this.panel2.Controls.Add(this.Min3);
            this.panel2.Controls.Add(this.Min2);
            this.panel2.Controls.Add(this.Min1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(201, 149);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(257, 204);
            this.panel2.TabIndex = 5;
            // 
            // TaxRate4
            // 
            this.TaxRate4.Location = new System.Drawing.Point(188, 136);
            this.TaxRate4.MaxLength = 7;
            this.TaxRate4.Name = "TaxRate4";
            this.TaxRate4.Size = new System.Drawing.Size(53, 20);
            this.TaxRate4.TabIndex = 18;
            this.TaxRate4.Text = "35.5";
            // 
            // TaxRate3
            // 
            this.TaxRate3.Location = new System.Drawing.Point(188, 110);
            this.TaxRate3.MaxLength = 7;
            this.TaxRate3.Name = "TaxRate3";
            this.TaxRate3.Size = new System.Drawing.Size(53, 20);
            this.TaxRate3.TabIndex = 17;
            this.TaxRate3.Text = "31.5";
            // 
            // TaxRate2
            // 
            this.TaxRate2.Location = new System.Drawing.Point(188, 84);
            this.TaxRate2.MaxLength = 5;
            this.TaxRate2.Name = "TaxRate2";
            this.TaxRate2.Size = new System.Drawing.Size(53, 20);
            this.TaxRate2.TabIndex = 16;
            this.TaxRate2.Text = "21.0";
            // 
            // TaxRate1
            // 
            this.TaxRate1.Location = new System.Drawing.Point(188, 58);
            this.TaxRate1.MaxLength = 5;
            this.TaxRate1.Name = "TaxRate1";
            this.TaxRate1.Size = new System.Drawing.Size(53, 20);
            this.TaxRate1.TabIndex = 15;
            this.TaxRate1.Text = "11.5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(90, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "Max";
            // 
            // Max4
            // 
            this.Max4.Location = new System.Drawing.Point(93, 136);
            this.Max4.MaxLength = 7;
            this.Max4.Name = "Max4";
            this.Max4.ReadOnly = true;
            this.Max4.Size = new System.Drawing.Size(58, 20);
            this.Max4.TabIndex = 13;
            this.Max4.Text = "and over";
            // 
            // Max3
            // 
            this.Max3.Location = new System.Drawing.Point(93, 110);
            this.Max3.MaxLength = 7;
            this.Max3.Name = "Max3";
            this.Max3.Size = new System.Drawing.Size(58, 20);
            this.Max3.TabIndex = 12;
            this.Max3.Text = "70000";
            this.Max3.TextChanged += new System.EventHandler(this.Max3_TextChanged);
            // 
            // Max2
            // 
            this.Max2.Location = new System.Drawing.Point(93, 84);
            this.Max2.MaxLength = 7;
            this.Max2.Name = "Max2";
            this.Max2.Size = new System.Drawing.Size(58, 20);
            this.Max2.TabIndex = 11;
            this.Max2.Text = "48000";
            this.Max2.TextChanged += new System.EventHandler(this.Max2_TextChanged);
            // 
            // Max1
            // 
            this.Max1.Location = new System.Drawing.Point(93, 58);
            this.Max1.MaxLength = 7;
            this.Max1.Name = "Max1";
            this.Max1.Size = new System.Drawing.Size(58, 20);
            this.Max1.TabIndex = 10;
            this.Max1.Text = "14000";
            this.Max1.TextChanged += new System.EventHandler(this.Max1_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(13, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "Min";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(176, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Tax Rate (%)";
            // 
            // Min4
            // 
            this.Min4.Location = new System.Drawing.Point(15, 136);
            this.Min4.MaxLength = 7;
            this.Min4.Name = "Min4";
            this.Min4.Size = new System.Drawing.Size(58, 20);
            this.Min4.TabIndex = 7;
            this.Min4.Text = "70000";
            this.Min4.TextChanged += new System.EventHandler(this.Min4_TextChanged);
            // 
            // Min3
            // 
            this.Min3.Location = new System.Drawing.Point(15, 110);
            this.Min3.MaxLength = 7;
            this.Min3.Name = "Min3";
            this.Min3.Size = new System.Drawing.Size(58, 20);
            this.Min3.TabIndex = 6;
            this.Min3.Text = "48000";
            this.Min3.TextChanged += new System.EventHandler(this.Min3_TextChanged);
            // 
            // Min2
            // 
            this.Min2.Location = new System.Drawing.Point(15, 84);
            this.Min2.MaxLength = 7;
            this.Min2.Name = "Min2";
            this.Min2.Size = new System.Drawing.Size(58, 20);
            this.Min2.TabIndex = 5;
            this.Min2.Text = "14000";
            this.Min2.TextChanged += new System.EventHandler(this.Min2_TextChanged);
            // 
            // Min1
            // 
            this.Min1.Location = new System.Drawing.Point(15, 58);
            this.Min1.MaxLength = 7;
            this.Min1.Name = "Min1";
            this.Min1.ReadOnly = true;
            this.Min1.Size = new System.Drawing.Size(58, 20);
            this.Min1.TabIndex = 4;
            this.Min1.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(43, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Tax Bracket";
            // 
            // TaxLiability
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(470, 365);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SalaryInput);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.panel2);
            this.Name = "TaxLiability";
            this.Text = "Tax Liability Calculator";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.TextBox SalaryInput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label OutputLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox Min2;
        private System.Windows.Forms.TextBox Min1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TaxRate4;
        private System.Windows.Forms.TextBox TaxRate3;
        private System.Windows.Forms.TextBox TaxRate2;
        private System.Windows.Forms.TextBox TaxRate1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Max3;
        private System.Windows.Forms.TextBox Max2;
        private System.Windows.Forms.TextBox Max1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Min4;
        private System.Windows.Forms.TextBox Min3;
        private System.Windows.Forms.TextBox Max4;
    }
}

