﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaxLabApplication
{
    public partial class TaxLiability : Form
    {
        public TaxLiability()
        {
            InitializeComponent();
            SalaryInput.ForeColor = SystemColors.GrayText;
            SalaryInput.Text = "$ Salary";
            this.SalaryInput.Leave += new System.EventHandler(this.SalaryInput_Leave);
            this.SalaryInput.Enter += new System.EventHandler(this.SalaryInput_Enter);
        }

        private void SalaryInput_Leave(object sender, EventArgs e)
        {
            if (SalaryInput.Text.Length == 0)
            {
                SalaryInput.Text = "$ Salary";
                SalaryInput.ForeColor = SystemColors.GrayText;
            }
        }

        private void SalaryInput_Enter(object sender, EventArgs e)
        {
            if (SalaryInput.Text == "$ Salary")
            {
                SalaryInput.Text = "";
                SalaryInput.ForeColor = SystemColors.WindowText;
            }
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            int salary, totalSalary;
            var salaryIsNumeric = int.TryParse(SalaryInput.Text, out salary);
            var max1isNumeric = int.TryParse(Max1.Text, out int max1);
            var max2isNumeric = int.TryParse(Max2.Text, out int max2);
            var max3isNumeric = int.TryParse(Max3.Text, out int max3);
            var tax1isNumeric = Double.TryParse(TaxRate1.Text, out double tax1);
            var tax2isNumeric = Double.TryParse(TaxRate2.Text, out double tax2);
            var tax3isNumeric = Double.TryParse(TaxRate3.Text, out double tax3);
            var tax4isNumeric = Double.TryParse(TaxRate4.Text, out double tax4);
            if (salaryIsNumeric && max1isNumeric && max2isNumeric && max3isNumeric && tax1isNumeric && tax2isNumeric && tax3isNumeric && tax4isNumeric && max1 < max2 && max2 < max3 && tax1 <= 100 && tax2 <= 100 && tax3 <= 100 && tax4 <= 100)
            {
                double taxFrom1, taxFrom2, taxFrom3, taxFrom4;
                if (salary >= max1)
                {
                    taxFrom1 = (double)max1 * (tax1 / 100);
                    totalSalary = salary - max1;
                    if (salary >= max2)
                    {
                        totalSalary = salary;
                        taxFrom2 = (double)(max2-max1) * (tax2 / 100);
                        totalSalary = totalSalary - max2;
                        if (salary >= max3)
                        {
                            totalSalary = salary;
                            taxFrom3 = (double)(max3-max2) * (tax3 / 100);
                            totalSalary = totalSalary - max3;
                            taxFrom4 = (double)totalSalary * (tax4 / 100);
                        }
                        else
                        {
                            taxFrom3 = (double)totalSalary * (tax3 / 100);
                            taxFrom4 = 0;
                        }
                    }
                    else
                    {
                        taxFrom2 = (double)totalSalary * (tax2 / 100);
                        taxFrom3 = 0;
                        taxFrom4 = 0;
                    }
                }
                else
                {
                    taxFrom1 = (double)salary * (tax1 / 100);
                    taxFrom2 = 0;
                    taxFrom3 = 0;
                    taxFrom4 = 0;
                }
                double tax = taxFrom1 + taxFrom2 + taxFrom3 + taxFrom4;
                string taxOutput = String.Format("{0:n}", Math.Round(tax, 2));
                OutputLabel.Text = taxOutput;
            }
            else if (!(tax1 <= 100 && tax2 <= 100 && tax3 <= 100 && tax4 <= 100))
            {
                MessageBox.Show("Tax Rate cannot be above 100%.",
                    "Incorrect Tax Rate Format",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                   );
            }
            else if (!(max1 < max2 && max2 < max3))
            {
                MessageBox.Show("The Tax Brackets you have specified are not correctly formatted.\n\nNote: The maximum value in the bracket above must be lower than the maximum value in the bracket below!",
                    "Incorrect Tax Rate Format",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                   );
            }
            else if (!(tax1isNumeric && tax2isNumeric && tax3isNumeric && tax4isNumeric))
            {
                MessageBox.Show("Please enter each Tax Rate as a decimal.",
                    "Incorrect Tax Rate Format",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                   );
            }
            else if (!(max1isNumeric && max2isNumeric && max3isNumeric))
            {
                MessageBox.Show("Please enter each Tax Bracket to the nearest dollar.",
                    "Incorrect Tax Bracket Format",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                   );
            }
            else
            {
                MessageBox.Show("Please enter your Salary to the nearest dollar.",
                    "Incorrect Salary Format",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                   );
            }
        }

        private void Min2_TextChanged(object sender, EventArgs e)
        {
            Max1.Text = Min2.Text;
        }

        private void Max1_TextChanged(object sender, EventArgs e)
        {
            Min2.Text = Max1.Text;
        }

        private void Max2_TextChanged(object sender, EventArgs e)
        {
            Min3.Text = Max2.Text;
        }

        private void Min3_TextChanged(object sender, EventArgs e)
        {
            Max2.Text = Min3.Text;
        }

        private void Min4_TextChanged(object sender, EventArgs e)
        {
            Max3.Text = Min4.Text;
        }

        private void Max3_TextChanged(object sender, EventArgs e)
        {
            Min4.Text = Max3.Text;
        }
    }
}
